package com.allkp.SpringAIDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAiDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
